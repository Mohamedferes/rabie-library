import { createContext, useContext, useEffect, useMemo, useState } from "react";

export type Category = {
  id: string;
  name: string;
  description: string;
  image: string;
  subcategories: string[];
};

export type Product = {
  id: string;
  name: string;
  author: string;
  price: number;
  rating: number;
  categoryId: string;
  image: string;
  description: string;
  stock: number;
  isNew?: boolean;
  isBestSeller?: boolean;
  isSpecial?: boolean;
};

export type CartItem = {
  productId: string;
  quantity: number;
};

export type StoreSettings = {
  storeName: string;
  background: string;
};

export type StoreSnapshot = {
  categories: Category[];
  products: Product[];
  settings: StoreSettings;
};

type StoreContextValue = {
  categories: Category[];
  products: Product[];
  cart: CartItem[];
  wishlist: string[];
  settings: StoreSettings;
  addToCart: (productId: string) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  toggleWishlist: (productId: string) => void;
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  addCategory: (category: Category) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (categoryId: string) => void;
  updateSettings: (settings: StoreSettings) => void;
  getSnapshot: () => StoreSnapshot;
  replaceSnapshot: (snapshot: StoreSnapshot) => void;
};

const StoreContext = createContext<StoreContextValue | undefined>(undefined);

const baseCategories: Category[] = [
  {
    id: "cat-books",
    name: "الكتب",
    description: "أكبر تشكيلة كتب عربية وعالمية مختارة بعناية.",
    image:
      "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=900&q=80",
    subcategories: [
      "الروايات",
      "الكتب الدينية",
      "التنمية الذاتية",
      "كتب الأطفال",
      "الكتب التعليمية",
    ],
  },
  {
    id: "cat-school-tools",
    name: "الأدوات المدرسية",
    description: "أقلام وملحقات مدرسية عالية الجودة.",
    image:
      "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=900&q=80",
    subcategories: [
      "الأقلام",
      "الممحاة",
      "المبراة",
      "المساطر",
      "الأقلام الملونة",
    ],
  },
  {
    id: "cat-notebooks",
    name: "الدفاتر والكراسات",
    description: "دفاتر أنيقة وكراسات عملية للدراسة والعمل.",
    image:
      "https://images.unsplash.com/photo-1501436513145-30f24e19fcc8?auto=format&fit=crop&w=900&q=80",
    subcategories: [
      "دفاتر مدرسية",
      "دفاتر ملاحظات",
      "دفاتر رسم",
      "أجندات",
    ],
  },
  {
    id: "cat-art",
    name: "الرسم والفنون",
    description: "كل أدوات الإبداع للرسم والفنون.",
    image:
      "https://images.unsplash.com/photo-1496317899792-9d7dbcd928a1?auto=format&fit=crop&w=900&q=80",
    subcategories: ["ألوان خشبية", "ألوان مائية", "فرش الرسم", "لوحات الرسم"],
  },
  {
    id: "cat-school-essentials",
    name: "اللوازم المدرسية",
    description: "مستلزمات مدرسية عصرية تناسب كل المراحل.",
    image:
      "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=900&q=80",
    subcategories: ["المحافظ المدرسية", "المقالم", "الأدوات الهندسية"],
  },
  {
    id: "cat-office",
    name: "المستلزمات المكتبية",
    description: "أدوات تنظيمية للمكاتب والعمل اليومي.",
    image:
      "https://images.unsplash.com/photo-1481887328591-3e277f9473dc?auto=format&fit=crop&w=900&q=80",
    subcategories: ["أوراق الطباعة", "الملفات", "الدباسات", "الأشرطة اللاصقة"],
  },
  {
    id: "cat-office-tech",
    name: "الإلكترونيات المكتبية",
    description: "أجهزة مكتبية حديثة تساعدك على الإنتاجية.",
    image:
      "https://images.unsplash.com/photo-1487014679447-9f8336841d58?auto=format&fit=crop&w=900&q=80",
    subcategories: ["الآلات الحاسبة", "الطابعات", "وحدات USB"],
  },
  {
    id: "cat-offers",
    name: "العروض الخاصة",
    description: "خصومات موسمية وباقات حصرية للقراءة.",
    image:
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80",
    subcategories: ["عروض كتب", "حزم مدرسية", "خصومات محدودة"],
  },
];

const baseProducts: Product[] = [
  {
    id: "p1",
    name: "رواية أطياف الربيع",
    author: "أحمد السعيد",
    price: 89,
    rating: 4.8,
    categoryId: "cat-books",
    image:
      "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=900&q=80",
    description: "رواية عربية ملهمة عن الشغف والبحث عن الذات.",
    stock: 35,
    isBestSeller: true,
  },
  {
    id: "p2",
    name: "دليل الروح اليومية",
    author: "دار النور",
    price: 64,
    rating: 4.7,
    categoryId: "cat-books",
    image:
      "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=900&q=80",
    description: "كتاب ديني يلهم القارئ بالتأمل والقيم.",
    stock: 42,
    isNew: true,
  },
  {
    id: "p3",
    name: "خطوات نحو التميز",
    author: "سارة الجبالي",
    price: 120,
    rating: 4.9,
    categoryId: "cat-books",
    image:
      "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&w=900&q=80",
    description: "كتاب تطوير ذاتي عملي لبناء العادات الناجحة.",
    stock: 28,
    isBestSeller: true,
  },
  {
    id: "p4",
    name: "مجموعة أقلام احترافية",
    author: "ستيشنيري بلس",
    price: 45,
    rating: 4.6,
    categoryId: "cat-school-tools",
    image:
      "https://images.unsplash.com/photo-1456735190827-d1262f71b8a3?auto=format&fit=crop&w=900&q=80",
    description: "أقلام ناعمة للحبر مع تصميم أنيق للطلاب.",
    stock: 120,
    isSpecial: true,
  },
  {
    id: "p5",
    name: "طقم أقلام ملونة",
    author: "ألوان ربيع",
    price: 75,
    rating: 4.8,
    categoryId: "cat-school-tools",
    image:
      "https://images.unsplash.com/photo-1491841651911-c44c30c34548?auto=format&fit=crop&w=900&q=80",
    description: "ألوان زاهية للرسم والتلوين المدرسي.",
    stock: 85,
    isNew: true,
  },
  {
    id: "p6",
    name: "دفاتر مدرسية فاخرة",
    author: "مكتبة ربيع",
    price: 40,
    rating: 4.5,
    categoryId: "cat-notebooks",
    image:
      "https://images.unsplash.com/photo-1501436513145-30f24e19fcc8?auto=format&fit=crop&w=900&q=80",
    description: "دفاتر مقسمة بتصميم عصري وجودة ممتازة.",
    stock: 160,
    isSpecial: true,
  },
  {
    id: "p7",
    name: "دفتر ملاحظات جلدي",
    author: "ستوديو ربيع",
    price: 92,
    rating: 4.7,
    categoryId: "cat-notebooks",
    image:
      "https://images.unsplash.com/photo-1512428559087-560fa5ceab42?auto=format&fit=crop&w=900&q=80",
    description: "دفتر ملاحظات فاخر للاجتماعات والملاحظات اليومية.",
    stock: 70,
    isBestSeller: true,
  },
  {
    id: "p8",
    name: "ألوان مائية احترافية",
    author: "أرتيستا",
    price: 135,
    rating: 4.6,
    categoryId: "cat-art",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
    description: "مجموعة ألوان مائية غنية بالدرجات.",
    stock: 48,
    isNew: true,
  },
  {
    id: "p9",
    name: "فرش رسم كلاسيكية",
    author: "أرتيستا",
    price: 55,
    rating: 4.4,
    categoryId: "cat-art",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
    description: "فرش متنوعة تناسب مختلف تقنيات الرسم.",
    stock: 90,
  },
  {
    id: "p10",
    name: "حقيبة مدرسية عصرية",
    author: "إيليت سكول",
    price: 210,
    rating: 4.8,
    categoryId: "cat-school-essentials",
    image:
      "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80",
    description: "حقيبة ظهر بخامات متينة وراحة عالية.",
    stock: 30,
    isBestSeller: true,
  },
  {
    id: "p11",
    name: "طقم أدوات هندسية",
    author: "جيومتري",
    price: 39,
    rating: 4.3,
    categoryId: "cat-school-essentials",
    image:
      "https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&fit=crop&w=900&q=80",
    description: "أدوات هندسية متكاملة للطلاب.",
    stock: 110,
  },
  {
    id: "p12",
    name: "رزمة أوراق طباعة",
    author: "أوفيس بلس",
    price: 32,
    rating: 4.5,
    categoryId: "cat-office",
    image:
      "https://images.unsplash.com/photo-1481887328591-3e277f9473dc?auto=format&fit=crop&w=900&q=80",
    description: "ورق أبيض عالي الجودة للطباعة اليومية.",
    stock: 200,
  },
  {
    id: "p13",
    name: "آلة حاسبة علمية",
    author: "كاليكس",
    price: 120,
    rating: 4.7,
    categoryId: "cat-office-tech",
    image:
      "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=900&q=80",
    description: "آلة حاسبة متعددة الوظائف للمدارس والجامعات.",
    stock: 65,
  },
  {
    id: "p14",
    name: "وحدة USB سريعة",
    author: "تك جير",
    price: 58,
    rating: 4.4,
    categoryId: "cat-office-tech",
    image:
      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80",
    description: "ذاكرة USB بسعة كبيرة وسرعة نقل عالية.",
    stock: 140,
  },
  {
    id: "p15",
    name: "حزمة القراءة الذهبية",
    author: "مكتبة ربيع",
    price: 199,
    rating: 4.9,
    categoryId: "cat-offers",
    image:
      "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&w=900&q=80",
    description: "باقة كتب مختارة بخصم خاص لعشاق القراءة.",
    stock: 25,
    isSpecial: true,
  },
  {
    id: "p16",
    name: "لوحة رسم قماشية",
    author: "أرتيستا",
    price: 70,
    rating: 4.5,
    categoryId: "cat-art",
    image:
      "https://images.unsplash.com/photo-1496317899792-9d7dbcd928a1?auto=format&fit=crop&w=900&q=80",
    description: "لوحات قماشية عالية الجودة للرسم الزيتي والمائي.",
    stock: 80,
  },
];

const STORAGE_KEY = "rabie-store";

const defaultSettings: StoreSettings = {
  storeName: "مكتبة ربيع",
  background:
    "radial-gradient(circle at top right, rgba(16, 185, 129, 0.12), transparent 55%), radial-gradient(circle at 20% 20%, rgba(14, 116, 144, 0.12), transparent 50%), linear-gradient(180deg, #f8fafc 0%, #ffffff 45%, #f1f5f9 100%)",
};

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [categories, setCategories] = useState<Category[]>(baseCategories);
  const [products, setProducts] = useState<Product[]>(baseProducts);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [settings, setSettings] = useState<StoreSettings>(defaultSettings);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored) as {
        products?: Product[];
        cart?: CartItem[];
        wishlist?: string[];
        categories?: Category[];
        settings?: StoreSettings;
      };
      if (parsed.products) setProducts(parsed.products);
      if (parsed.cart) setCart(parsed.cart);
      if (parsed.wishlist) setWishlist(parsed.wishlist);
      if (parsed.categories) setCategories(parsed.categories);
      if (parsed.settings) setSettings(parsed.settings);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ products, cart, wishlist, categories, settings })
    );
  }, [products, cart, wishlist, categories, settings]);

  const addToCart = (productId: string) => {
    setCart((prev) => {
      const item = prev.find((entry) => entry.productId === productId);
      if (item) {
        return prev.map((entry) =>
          entry.productId === productId
            ? { ...entry, quantity: entry.quantity + 1 }
            : entry
        );
      }
      return [...prev, { productId, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((entry) => entry.productId !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((entry) =>
        entry.productId === productId ? { ...entry, quantity } : entry
      )
    );
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const addProduct = (product: Product) => {
    setProducts((prev) => [...prev, product]);
  };

  const updateProduct = (product: Product) => {
    setProducts((prev) =>
      prev.map((entry) => (entry.id === product.id ? product : entry))
    );
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((entry) => entry.id !== productId));
  };

  const addCategory = (category: Category) => {
    setCategories((prev) => [...prev, category]);
  };

  const updateCategory = (category: Category) => {
    setCategories((prev) =>
      prev.map((entry) => (entry.id === category.id ? category : entry))
    );
  };

  const deleteCategory = (categoryId: string) => {
    setCategories((prev) => prev.filter((entry) => entry.id !== categoryId));
  };

  const updateSettings = (nextSettings: StoreSettings) => {
    setSettings(nextSettings);
  };

  const getSnapshot = () => ({ categories, products, settings });

  const replaceSnapshot = (snapshot: StoreSnapshot) => {
    setCategories(snapshot.categories);
    setProducts(snapshot.products);
    setSettings(snapshot.settings);
  };

  const value = useMemo(
    () => ({
      categories,
      products,
      cart,
      wishlist,
      settings,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      toggleWishlist,
      addProduct,
      updateProduct,
      deleteProduct,
      addCategory,
      updateCategory,
      deleteCategory,
      updateSettings,
      getSnapshot,
      replaceSnapshot,
    }),
    [
      categories,
      products,
      cart,
      wishlist,
      settings,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      toggleWishlist,
      addProduct,
      updateProduct,
      deleteProduct,
      addCategory,
      updateCategory,
      deleteCategory,
      updateSettings,
      getSnapshot,
      replaceSnapshot,
    ]
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error("useStore must be used within StoreProvider");
  }
  return context;
};
