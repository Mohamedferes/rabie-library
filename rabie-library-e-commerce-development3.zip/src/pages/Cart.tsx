import { Link } from "react-router-dom";
import { Trash2 } from "lucide-react";
import SectionHeading from "../components/SectionHeading";
import { useStore } from "../context/StoreContext";

export default function Cart() {
  const { cart, products, updateCartQuantity, removeFromCart } = useStore();
  const items = cart.map((item) => ({
    ...item,
    product: products.find((product) => product.id === item.productId)!,
  }));
  const total = items.reduce(
    (sum, item) => sum + item.quantity * item.product.price,
    0
  );

  return (
    <div className="space-y-10">
      <SectionHeading title="سلة التسوق" subtitle="السلة" />
      {items.length === 0 ? (
        <div className="rounded-3xl border border-slate-200 bg-white p-10 text-center">
          <p className="text-lg font-semibold text-slate-900">
            سلتك فارغة حتى الآن.
          </p>
          <Link
            to="/products"
            className="mt-4 inline-flex rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white"
          >
            استعرض المنتجات
          </Link>
        </div>
      ) : (
        <div className="grid gap-8 lg:grid-cols-[1.6fr_0.9fr]">
          <div className="space-y-4">
            {items.map((item) => (
              <div
                key={item.productId}
                className="flex flex-wrap items-center gap-4 rounded-3xl border border-slate-100 bg-white p-4 shadow-sm"
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="h-20 w-20 rounded-2xl object-cover"
                />
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-900">
                    {item.product.name}
                  </p>
                  <p className="text-xs text-slate-500">
                    {item.product.author}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      updateCartQuantity(item.productId, item.quantity - 1)
                    }
                    className="h-8 w-8 rounded-full border border-slate-200 text-sm"
                  >
                    -
                  </button>
                  <span className="text-sm font-semibold">{item.quantity}</span>
                  <button
                    onClick={() =>
                      updateCartQuantity(item.productId, item.quantity + 1)
                    }
                    className="h-8 w-8 rounded-full border border-slate-200 text-sm"
                  >
                    +
                  </button>
                </div>
                <p className="text-sm font-semibold text-slate-900">
                  {item.product.price * item.quantity} درهم
                </p>
                <button
                  onClick={() => removeFromCart(item.productId)}
                  className="rounded-full border border-slate-200 p-2 text-slate-500"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
          <div className="h-fit rounded-3xl border border-slate-100 bg-white p-6 shadow-sm">
            <p className="text-sm font-semibold text-slate-900">ملخص الطلب</p>
            <div className="mt-4 space-y-3 text-sm text-slate-600">
              <div className="flex items-center justify-between">
                <span>الإجمالي</span>
                <span className="font-semibold text-slate-900">{total} درهم</span>
              </div>
              <div className="flex items-center justify-between">
                <span>الشحن</span>
                <span className="font-semibold text-slate-900">مجاني</span>
              </div>
              <div className="flex items-center justify-between border-t border-dashed border-slate-200 pt-3">
                <span>المبلغ النهائي</span>
                <span className="text-lg font-bold text-slate-900">{total} درهم</span>
              </div>
            </div>
            <Link
              to="/checkout"
              className="mt-6 inline-flex w-full justify-center rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white"
            >
              إتمام الشراء
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
