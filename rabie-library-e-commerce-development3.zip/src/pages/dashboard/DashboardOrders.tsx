import DashboardLayout from "../../components/DashboardLayout";

const orders = [
  { id: "#RB-4021", customer: "ليان العنزي", total: "420 درهم", status: "قيد التجهيز" },
  { id: "#RB-4022", customer: "خالد الحربي", total: "210 درهم", status: "تم الشحن" },
  { id: "#RB-4023", customer: "أمل الشريف", total: "520 درهم", status: "مكتمل" },
];

export default function DashboardOrders() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-500">
            الطلبات
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">
            متابعة الطلبات الحالية
          </h1>
        </div>
        <div className="overflow-hidden rounded-[32px] border border-slate-100 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3 text-right">رقم الطلب</th>
                <th className="px-4 py-3 text-right">العميل</th>
                <th className="px-4 py-3 text-right">الإجمالي</th>
                <th className="px-4 py-3 text-right">الحالة</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id} className="border-t border-slate-100">
                  <td className="px-4 py-3 font-semibold text-slate-900">
                    {order.id}
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    {order.customer}
                  </td>
                  <td className="px-4 py-3 text-slate-600">{order.total}</td>
                  <td className="px-4 py-3 text-slate-600">{order.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
