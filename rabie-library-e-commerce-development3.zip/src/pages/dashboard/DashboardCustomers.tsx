import DashboardLayout from "../../components/DashboardLayout";

const customers = [
  { name: "ليان العنزي", email: "layan@mail.com", orders: 12 },
  { name: "عبدالله الشريف", email: "abdullah@mail.com", orders: 8 },
  { name: "هديل القحطاني", email: "hadeel@mail.com", orders: 5 },
];

export default function DashboardCustomers() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-500">
            العملاء
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">
            قاعدة عملاء مكتبة ربيع
          </h1>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {customers.map((customer) => (
            <div
              key={customer.email}
              className="rounded-3xl border border-slate-100 bg-white p-5 shadow-sm"
            >
              <p className="text-sm font-semibold text-slate-900">
                {customer.name}
              </p>
              <p className="text-xs text-slate-500">{customer.email}</p>
              <p className="mt-3 text-xs text-slate-500">
                عدد الطلبات: {customer.orders}
              </p>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
