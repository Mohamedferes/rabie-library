import { useState } from "react";
import DashboardLayout from "../../components/DashboardLayout";
import { StoreSettings, useStore } from "../../context/StoreContext";

export default function DashboardSettings() {
  const { settings, updateSettings, getSnapshot, replaceSnapshot } = useStore();
  const [form, setForm] = useState<StoreSettings>(settings);
  const [importError, setImportError] = useState<string | null>(null);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    updateSettings(form);
  };

  const handleExport = () => {
    const data = JSON.stringify(getSnapshot(), null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "rabie-store-data.json";
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result as string);
        replaceSnapshot(parsed);
        setImportError(null);
      } catch (error) {
        setImportError("الملف غير صالح، يرجى رفع ملف JSON صحيح.");
      }
    };
    reader.readAsText(file);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-500">
            الإعدادات
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">
            تخصيص عنوان المتجر والخلفية
          </h1>
        </div>
        <form
          onSubmit={handleSubmit}
          className="grid gap-4 rounded-[32px] border border-slate-100 bg-white p-6 shadow-sm"
        >
          <div className="grid gap-4 md:grid-cols-2">
            <input
              value={form.storeName}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, storeName: event.target.value }))
              }
              className="rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
              placeholder="اسم المتجر"
            />
            <input
              value={form.background}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, background: event.target.value }))
              }
              className="rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
              placeholder="خلفية المتجر (CSS background)"
            />
          </div>
          <div
            className="rounded-3xl border border-dashed border-slate-200 p-4"
            style={{ background: form.background }}
          >
            <p className="text-sm font-semibold text-slate-800">
              معاينة الخلفية الجديدة
            </p>
            <p className="text-xs text-slate-600">
              يمكنك إدخال تدرج لوني أو رابط صورة باستخدام CSS.
            </p>
          </div>
          <button className="rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white">
            حفظ الإعدادات
          </button>
        </form>

        <div className="grid gap-4 rounded-[32px] border border-slate-100 bg-white p-6 shadow-sm md:grid-cols-2">
          <div className="space-y-3">
            <p className="text-sm font-semibold text-slate-900">
              مزامنة البيانات بين الأجهزة
            </p>
            <p className="text-xs text-slate-600">
              البيانات تحفظ محليًا على هذا الجهاز. لتحويل التعديلات إلى جهاز آخر،
              قم بتصدير الملف ثم استيراده هناك.
            </p>
            <button
              type="button"
              onClick={handleExport}
              className="rounded-full bg-slate-900 px-5 py-2 text-xs font-semibold text-white"
            >
              تصدير البيانات
            </button>
          </div>
          <div className="space-y-3">
            <p className="text-sm font-semibold text-slate-900">
              استيراد بيانات المتجر
            </p>
            <input
              type="file"
              accept="application/json"
              onChange={(event) => handleImport(event.target.files?.[0] ?? null)}
              className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm"
            />
            {importError ? (
              <p className="text-xs text-rose-500">{importError}</p>
            ) : (
              <p className="text-xs text-slate-500">
                استخدم ملف JSON الذي تم تصديره من لوحة التحكم.
              </p>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
