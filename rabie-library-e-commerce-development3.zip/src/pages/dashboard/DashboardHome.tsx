import DashboardLayout from "../../components/DashboardLayout";

const stats = [
  { label: "إجمالي المبيعات", value: "452K درهم" },
  { label: "طلبات اليوم", value: "128" },
  { label: "منتجات نشطة", value: "1,240" },
  { label: "عملاء جدد", value: "86" },
];

export default function DashboardHome() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-500">
            لوحة التحكم
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">
            مرحبًا بك في إدارة مكتبة ربيع
          </h1>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="rounded-3xl border border-slate-100 bg-white p-5 shadow-sm"
            >
              <p className="text-sm text-slate-500">{stat.label}</p>
              <p className="mt-3 text-xl font-bold text-slate-900">
                {stat.value}
              </p>
            </div>
          ))}
        </div>
        <div className="rounded-[32px] border border-slate-100 bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold text-slate-900">تقرير سريع</p>
          <p className="mt-3 text-sm text-slate-600">
            تم تحديث جميع المنتجات والعروض بنجاح. يمكنك إدارة المنتجات، تعديل
            الأسعار، أو إضافة منتجات جديدة مباشرة من لوحة التحكم.
          </p>
        </div>
      </div>
    </DashboardLayout>
  );
}
