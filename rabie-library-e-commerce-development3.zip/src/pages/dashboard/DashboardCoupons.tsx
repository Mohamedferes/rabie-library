import DashboardLayout from "../../components/DashboardLayout";

const coupons = [
  { code: "RABIE20", discount: "20%" },
  { code: "BOOK10", discount: "10%" },
  { code: "SPRING15", discount: "15%" },
];

export default function DashboardCoupons() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-500">
            الكوبونات
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">
            إدارة كوبونات الخصم
          </h1>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {coupons.map((coupon) => (
            <div
              key={coupon.code}
              className="rounded-3xl border border-slate-100 bg-white p-5 shadow-sm"
            >
              <p className="text-sm font-semibold text-slate-900">
                {coupon.code}
              </p>
              <p className="mt-2 text-sm text-slate-600">
                خصم {coupon.discount}
              </p>
              <button className="mt-4 rounded-full border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600">
                تعديل الكوبون
              </button>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
