import { useState } from "react";
import DashboardLayout from "../../components/DashboardLayout";
import { Category, useStore } from "../../context/StoreContext";

const emptyForm: Omit<Category, "id"> = {
  name: "",
  description: "",
  image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=900&q=80",
  subcategories: [],
};

export default function DashboardCategories() {
  const { categories, addCategory, updateCategory, deleteCategory } = useStore();
  const [form, setForm] = useState<Omit<Category, "id">>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.name.trim()) return;
    const categoryPayload: Category = {
      ...form,
      id: editingId ?? `cat-${Date.now()}`,
    };
    if (editingId) {
      updateCategory(categoryPayload);
      setEditingId(null);
    } else {
      addCategory(categoryPayload);
    }
    setForm(emptyForm);
  };

  const handleEdit = (category: Category) => {
    const { id, ...rest } = category;
    setEditingId(id);
    setForm({ ...emptyForm, ...rest });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-500">
            التصنيفات
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">
            إدارة تصنيفات المتجر وتفاصيلها
          </h1>
        </div>
        <form
          onSubmit={handleSubmit}
          className="grid gap-4 rounded-[32px] border border-slate-100 bg-white p-6 shadow-sm md:grid-cols-2"
        >
          <input
            value={form.name}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, name: event.target.value }))
            }
            className="rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="اسم التصنيف"
          />
          <input
            value={form.image}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, image: event.target.value }))
            }
            className="rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="رابط صورة التصنيف"
          />
          <textarea
            value={form.description}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, description: event.target.value }))
            }
            className="md:col-span-2 h-24 rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="وصف التصنيف"
          />
          <input
            value={form.subcategories.join(", ")}
            onChange={(event) =>
              setForm((prev) => ({
                ...prev,
                subcategories: event.target.value
                  .split(",")
                  .map((item) => item.trim())
                  .filter(Boolean),
              }))
            }
            className="md:col-span-2 rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="التصنيفات الفرعية (افصل بينها بفاصلة)"
          />
          <button className="md:col-span-2 rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white">
            {editingId ? "تحديث التصنيف" : "إضافة التصنيف"}
          </button>
        </form>

        <div className="grid gap-4 md:grid-cols-2">
          {categories.map((category) => (
            <div
              key={category.id}
              className="rounded-3xl border border-slate-100 bg-white p-5 shadow-sm"
            >
              <div className="flex items-center gap-4">
                <img
                  src={category.image}
                  alt={category.name}
                  className="h-16 w-16 rounded-2xl object-cover"
                />
                <div>
                  <p className="text-sm font-semibold text-slate-900">
                    {category.name}
                  </p>
                  <p className="text-xs text-slate-500">
                    {category.description}
                  </p>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {category.subcategories.map((subcategory) => (
                  <span
                    key={subcategory}
                    className="rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1 text-xs text-emerald-700"
                  >
                    {subcategory}
                  </span>
                ))}
              </div>
              <div className="mt-4 flex gap-2">
                <button
                  type="button"
                  onClick={() => handleEdit(category)}
                  className="rounded-full border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600"
                >
                  تعديل التصنيف
                </button>
                <button
                  type="button"
                  onClick={() => deleteCategory(category.id)}
                  className="rounded-full border border-rose-200 px-4 py-2 text-xs font-semibold text-rose-500"
                >
                  حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
