import DashboardLayout from "../../components/DashboardLayout";
import { offers } from "../../data/storeContent";

export default function DashboardOffers() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-500">
            العروض
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">
            إدارة العروض الخاصة
          </h1>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {offers.map((offer) => (
            <div
              key={offer.title}
              className="rounded-3xl border border-slate-100 bg-white p-5 shadow-sm"
            >
              <p className="text-sm font-semibold text-slate-900">
                {offer.title}
              </p>
              <p className="mt-2 text-sm text-slate-600">
                {offer.description}
              </p>
              <button className="mt-4 rounded-full border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600">
                تعديل العرض
              </button>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
