import { useState } from "react";
import DashboardLayout from "../../components/DashboardLayout";
import { Product, useStore } from "../../context/StoreContext";

const emptyForm: Omit<Product, "id"> = {
  name: "",
  author: "",
  price: 0,
  rating: 4.5,
  categoryId: "cat-books",
  image: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=900&q=80",
  description: "",
  stock: 0,
  isNew: false,
  isBestSeller: false,
  isSpecial: false,
};

export default function DashboardProducts() {
  const { products, categories, addProduct, updateProduct, deleteProduct } =
    useStore();
  const [form, setForm] = useState<Omit<Product, "id">>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.name.trim()) return;
    if (editingId) {
      updateProduct({ ...form, id: editingId });
      setEditingId(null);
    } else {
      addProduct({ ...form, id: `p-${Date.now()}` });
    }
    setForm(emptyForm);
  };

  const handleEdit = (product: Product) => {
    setEditingId(product.id);
    const { id, ...rest } = product;
    setForm({ ...emptyForm, ...rest });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-500">
            إدارة المنتجات
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">
            إضافة وتعديل المنتجات بسهولة
          </h1>
        </div>
        <form
          onSubmit={handleSubmit}
          className="grid gap-4 rounded-[32px] border border-slate-100 bg-white p-6 shadow-sm md:grid-cols-2"
        >
          <input
            value={form.name}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, name: event.target.value }))
            }
            className="rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="اسم المنتج"
          />
          <input
            value={form.author}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, author: event.target.value }))
            }
            className="rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="المؤلف / العلامة"
          />
          <div className="flex items-center overflow-hidden rounded-2xl border border-slate-200 text-sm">
            <button
              type="button"
              onClick={() =>
                setForm((prev) => ({ ...prev, price: Math.max(0, prev.price - 1) }))
              }
              className="px-4 py-3 text-slate-500 hover:bg-slate-50"
            >
              -
            </button>
            <input
              type="number"
              value={form.price}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  price: Number(event.target.value),
                }))
              }
              className="w-full flex-1 border-0 px-2 py-3 text-center focus:outline-none"
              placeholder="السعر"
            />
            <button
              type="button"
              onClick={() =>
                setForm((prev) => ({ ...prev, price: prev.price + 1 }))
              }
              className="px-4 py-3 text-slate-500 hover:bg-slate-50"
            >
              +
            </button>
          </div>
          <div className="flex items-center overflow-hidden rounded-2xl border border-slate-200 text-sm">
            <button
              type="button"
              onClick={() =>
                setForm((prev) => ({ ...prev, stock: Math.max(0, prev.stock - 1) }))
              }
              className="px-4 py-3 text-slate-500 hover:bg-slate-50"
            >
              -
            </button>
            <input
              type="number"
              value={form.stock}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  stock: Number(event.target.value),
                }))
              }
              className="w-full flex-1 border-0 px-2 py-3 text-center focus:outline-none"
              placeholder="المخزون"
            />
            <button
              type="button"
              onClick={() =>
                setForm((prev) => ({ ...prev, stock: prev.stock + 1 }))
              }
              className="px-4 py-3 text-slate-500 hover:bg-slate-50"
            >
              +
            </button>
          </div>
          <div className="flex items-center overflow-hidden rounded-2xl border border-slate-200 text-sm">
            <button
              type="button"
              onClick={() =>
                setForm((prev) => ({
                  ...prev,
                  rating: Math.max(0, Number((prev.rating - 0.1).toFixed(1))),
                }))
              }
              className="px-4 py-3 text-slate-500 hover:bg-slate-50"
            >
              -
            </button>
            <input
              type="number"
              step="0.1"
              value={form.rating}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  rating: Number(event.target.value),
                }))
              }
              className="w-full flex-1 border-0 px-2 py-3 text-center focus:outline-none"
              placeholder="التقييم"
            />
            <button
              type="button"
              onClick={() =>
                setForm((prev) => ({
                  ...prev,
                  rating: Math.min(5, Number((prev.rating + 0.1).toFixed(1))),
                }))
              }
              className="px-4 py-3 text-slate-500 hover:bg-slate-50"
            >
              +
            </button>
          </div>
          <select
            value={form.categoryId}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, categoryId: event.target.value }))
            }
            className="rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
          >
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
          <input
            value={form.image}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, image: event.target.value }))
            }
            className="rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="رابط الصورة"
          />
          <textarea
            value={form.description}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, description: event.target.value }))
            }
            className="md:col-span-2 h-28 rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="وصف المنتج"
          />
          <div className="md:col-span-2 flex flex-wrap gap-4 text-sm text-slate-600">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.isNew}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, isNew: event.target.checked }))
                }
              />
              منتج جديد
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.isBestSeller}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    isBestSeller: event.target.checked,
                  }))
                }
              />
              الأكثر مبيعًا
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.isSpecial}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    isSpecial: event.target.checked,
                  }))
                }
              />
              عرض خاص
            </label>
          </div>
          <button className="md:col-span-2 rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white">
            {editingId ? "تحديث المنتج" : "إضافة المنتج"}
          </button>
        </form>

        <div className="overflow-hidden rounded-[32px] border border-slate-100 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3 text-right">المنتج</th>
                <th className="px-4 py-3 text-right">السعر</th>
                <th className="px-4 py-3 text-right">المخزون</th>
                <th className="px-4 py-3 text-right">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="border-t border-slate-100">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="h-10 w-10 rounded-xl object-cover"
                      />
                      <div>
                        <p className="font-semibold text-slate-900">
                          {product.name}
                        </p>
                        <p className="text-xs text-slate-500">
                          {product.author}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    {product.price} درهم
                  </td>
                  <td className="px-4 py-3 text-slate-600">{product.stock}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => handleEdit(product)}
                        className="rounded-full border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-600"
                      >
                        تعديل
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteProduct(product.id)}
                        className="rounded-full border border-rose-200 px-3 py-1 text-xs font-semibold text-rose-500"
                      >
                        حذف
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
