import { Link, useParams } from "react-router-dom";
import { Heart, ShoppingBag, Star } from "lucide-react";
import { useStore } from "../context/StoreContext";

export default function ProductDetails() {
  const { id } = useParams();
  const { products, addToCart, toggleWishlist, wishlist } = useStore();
  const product = products.find((item) => item.id === id);

  if (!product) {
    return (
      <div className="rounded-3xl border border-slate-200 bg-white p-10 text-center">
        <p className="text-lg font-semibold text-slate-900">
          المنتج غير متوفر.
        </p>
        <Link
          to="/products"
          className="mt-4 inline-flex rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white"
        >
          العودة للمنتجات
        </Link>
      </div>
    );
  }

  return (
    <div className="grid gap-12 md:grid-cols-[1fr_1.1fr]">
      <img
        src={product.image}
        alt={product.name}
        className="h-96 w-full rounded-[32px] object-cover shadow-lg"
      />
      <div className="space-y-6">
        <div>
          <p className="text-sm font-semibold text-emerald-600">{product.author}</p>
          <h1 className="mt-2 text-3xl font-bold text-slate-900">
            {product.name}
          </h1>
        </div>
        <div className="flex items-center gap-3 text-amber-500">
          <Star className="h-5 w-5 fill-current" />
          <span className="text-sm font-semibold text-slate-700">
            {product.rating} تقييمات العملاء
          </span>
        </div>
        <p className="text-sm leading-relaxed text-slate-600">
          {product.description}
        </p>
        <div className="flex items-center gap-6">
          <p className="text-3xl font-bold text-slate-900">
            {product.price} درهم
          </p>
          <span className="rounded-full bg-emerald-50 px-4 py-2 text-xs font-semibold text-emerald-700">
            متوفر {product.stock} نسخة
          </span>
        </div>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => addToCart(product.id)}
            className="flex items-center gap-2 rounded-full bg-slate-900 px-6 py-3 text-sm font-semibold text-white"
          >
            <ShoppingBag className="h-4 w-4" />
            أضف للسلة
          </button>
          <button
            onClick={() => toggleWishlist(product.id)}
            className="flex items-center gap-2 rounded-full border border-slate-200 px-6 py-3 text-sm font-semibold text-slate-600"
          >
            <Heart className={`h-4 w-4 ${wishlist.includes(product.id) ? "text-rose-500" : ""}`} />
            {wishlist.includes(product.id) ? "ضمن المفضلة" : "أضف للمفضلة"}
          </button>
        </div>
      </div>
    </div>
  );
}
