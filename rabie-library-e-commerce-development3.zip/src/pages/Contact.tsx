import type { FormEvent } from "react";
import SectionHeading from "../components/SectionHeading";

export default function Contact() {
  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
  };

  return (
    <div className="space-y-10">
      <SectionHeading title="تواصل معنا" subtitle="الدعم" />
      <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
        <form
          onSubmit={handleSubmit}
          className="space-y-4 rounded-[32px] border border-slate-100 bg-white p-8 shadow-sm"
        >
          <input
            className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="الاسم الكامل"
          />
          <input
            className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="البريد الإلكتروني"
          />
          <input
            className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="عنوان الرسالة"
          />
          <textarea
            className="h-32 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
            placeholder="كيف يمكننا مساعدتك؟"
          />
          <button className="w-full rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white">
            إرسال الرسالة
          </button>
        </form>
        <div className="space-y-4 rounded-[32px] border border-emerald-100 bg-emerald-50 p-6">
          <p className="text-sm font-semibold text-emerald-700">معلومات التواصل</p>
          <div className="text-sm text-emerald-800">
            <p>البريد الإلكتروني: care@rabiebooks.sa</p>
            <p>الهاتف: 9200 12345</p>
            <p>الرياض - حي الربيع</p>
          </div>
          <div className="rounded-3xl bg-white p-4 text-xs text-slate-500">
            متواجدون يوميًا من 9 صباحًا حتى 9 مساءً.
          </div>
        </div>
      </div>
    </div>
  );
}
