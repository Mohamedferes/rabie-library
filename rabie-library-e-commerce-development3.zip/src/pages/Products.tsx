import SectionHeading from "../components/SectionHeading";
import ProductCard from "../components/ProductCard";
import { useStore } from "../context/StoreContext";

export default function Products() {
  const { products, categories } = useStore();

  return (
    <div className="space-y-10">
      <SectionHeading title="جميع المنتجات" subtitle="المنتجات" />
      <div className="flex flex-wrap gap-3">
        {categories.map((category) => (
          <span
            key={category.id}
            className="rounded-full border border-emerald-100 bg-emerald-50 px-4 py-2 text-xs font-semibold text-emerald-700"
          >
            {category.name}
          </span>
        ))}
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
