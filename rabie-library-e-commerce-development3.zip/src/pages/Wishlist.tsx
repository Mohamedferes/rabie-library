import { Link } from "react-router-dom";
import SectionHeading from "../components/SectionHeading";
import ProductCard from "../components/ProductCard";
import { useStore } from "../context/StoreContext";

export default function Wishlist() {
  const { wishlist, products } = useStore();
  const items = products.filter((product) => wishlist.includes(product.id));

  return (
    <div className="space-y-10">
      <SectionHeading title="قائمة المفضلة" subtitle="المفضلة" />
      {items.length === 0 ? (
        <div className="rounded-3xl border border-slate-200 bg-white p-10 text-center">
          <p className="text-lg font-semibold text-slate-900">
            لم تقم بإضافة أي منتج للمفضلة بعد.
          </p>
          <Link
            to="/products"
            className="mt-4 inline-flex rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white"
          >
            استعرض المنتجات
          </Link>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {items.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
