import type { FormEvent } from "react";
import { Link } from "react-router-dom";
import SectionHeading from "../components/SectionHeading";

export default function Login() {
  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
  };

  return (
    <div className="mx-auto max-w-xl space-y-8">
      <SectionHeading title="تسجيل الدخول" subtitle="الحساب" />
      <form
        onSubmit={handleSubmit}
        className="space-y-4 rounded-[32px] border border-slate-100 bg-white p-8 shadow-sm"
      >
        <input
          className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
          placeholder="البريد الإلكتروني"
        />
        <input
          type="password"
          className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
          placeholder="كلمة المرور"
        />
        <button className="w-full rounded-full bg-slate-900 px-6 py-3 text-sm font-semibold text-white">
          دخول
        </button>
        <Link
          to="/dashboard"
          className="inline-flex w-full justify-center rounded-full border border-emerald-200 px-6 py-3 text-sm font-semibold text-emerald-700"
        >
          دخول لوحة التحكم (للمالك)
        </Link>
        <p className="text-center text-sm text-slate-500">
          ليس لديك حساب؟
          <Link to="/register" className="mr-2 text-emerald-600">
            إنشاء حساب
          </Link>
        </p>
      </form>
    </div>
  );
}
