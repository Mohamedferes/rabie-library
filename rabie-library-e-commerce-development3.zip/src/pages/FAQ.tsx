import SectionHeading from "../components/SectionHeading";
import { faqs } from "../data/storeContent";

export default function FAQ() {
  return (
    <div className="space-y-10">
      <SectionHeading title="الأسئلة الشائعة" subtitle="الدعم" />
      <div className="space-y-4">
        {faqs.map((faq) => (
          <div
            key={faq.question}
            className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm"
          >
            <p className="text-sm font-semibold text-slate-900">
              {faq.question}
            </p>
            <p className="mt-2 text-sm text-slate-600">{faq.answer}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
