import { Link } from "react-router-dom";
import SectionHeading from "../components/SectionHeading";
import { offers } from "../data/storeContent";

export default function Offers() {
  return (
    <div className="space-y-10">
      <SectionHeading title="العروض الخاصة" subtitle="العروض" />
      <div className="grid gap-6 md:grid-cols-2">
        {offers.map((offer) => (
          <div
            key={offer.title}
            className="rounded-3xl border border-emerald-100 bg-emerald-50 p-6"
          >
            <p className="text-lg font-semibold text-emerald-900">
              {offer.title}
            </p>
            <p className="mt-2 text-sm text-emerald-800">
              {offer.description}
            </p>
            <Link
              to="/products"
              className="mt-4 inline-flex rounded-full bg-emerald-600 px-5 py-2 text-xs font-semibold text-white"
            >
              استفد الآن
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
