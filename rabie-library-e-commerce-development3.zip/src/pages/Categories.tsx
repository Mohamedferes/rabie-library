import { Link } from "react-router-dom";
import SectionHeading from "../components/SectionHeading";
import { useStore } from "../context/StoreContext";

export default function Categories() {
  const { categories } = useStore();

  return (
    <div className="space-y-10">
      <SectionHeading title="تصنيفات مكتبة ربيع" subtitle="التصنيفات" />
      <div className="grid gap-6 md:grid-cols-2">
        {categories.map((category) => (
          <div
            key={category.id}
            className="grid gap-6 rounded-[32px] border border-slate-100 bg-white p-6 shadow-sm md:grid-cols-[0.9fr_1.1fr]"
          >
            <img
              src={category.image}
              alt={category.name}
              className="h-48 w-full rounded-3xl object-cover"
            />
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-slate-900">
                {category.name}
              </h3>
              <p className="text-sm text-slate-600">
                {category.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {category.subcategories.map((subcategory) => (
                  <span
                    key={subcategory}
                    className="rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1 text-xs text-emerald-700"
                  >
                    {subcategory}
                  </span>
                ))}
              </div>
              <Link
                to="/products"
                className="inline-flex rounded-full bg-emerald-600 px-5 py-2 text-xs font-semibold text-white"
              >
                استعرض المنتجات
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
