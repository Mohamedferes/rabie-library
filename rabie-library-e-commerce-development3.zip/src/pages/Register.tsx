import type { FormEvent } from "react";
import { Link } from "react-router-dom";
import SectionHeading from "../components/SectionHeading";

export default function Register() {
  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
  };

  return (
    <div className="mx-auto max-w-xl space-y-8">
      <SectionHeading title="إنشاء حساب" subtitle="الحساب" />
      <form
        onSubmit={handleSubmit}
        className="space-y-4 rounded-[32px] border border-slate-100 bg-white p-8 shadow-sm"
      >
        <input
          className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
          placeholder="الاسم الكامل"
        />
        <input
          className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
          placeholder="البريد الإلكتروني"
        />
        <input
          type="password"
          className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
          placeholder="كلمة المرور"
        />
        <button className="w-full rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white">
          إنشاء الحساب
        </button>
        <p className="text-center text-sm text-slate-500">
          لديك حساب بالفعل؟
          <Link to="/login" className="mr-2 text-emerald-600">
            تسجيل الدخول
          </Link>
        </p>
      </form>
    </div>
  );
}
