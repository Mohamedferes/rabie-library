import SectionHeading from "../components/SectionHeading";

export default function About() {
  return (
    <div className="space-y-10">
      <SectionHeading title="من نحن" subtitle="قصتنا" />
      <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="space-y-4 rounded-[32px] border border-slate-100 bg-white p-8 shadow-sm">
          <p className="text-sm leading-7 text-slate-600">
            مكتبة ربيع تأسست لتقديم تجربة قراءة فاخرة، تجمع بين الكتب الأكثر
            تأثيرًا وأدوات القرطاسية الراقية. نؤمن أن المعرفة أسلوب حياة، لذلك
            نختار منتجاتنا بعناية ونوفر خدمة شخصية تناسب تطلعات عملائنا.
          </p>
          <p className="text-sm leading-7 text-slate-600">
            نعمل مع دور نشر عربية وعالمية معتمدة، ونقدم توصيات شهرية مبنية على
            تحليل الاتجاهات القرائية في المنطقة.
          </p>
        </div>
        <div className="space-y-4 rounded-[32px] border border-emerald-100 bg-emerald-50 p-6">
          <p className="text-sm font-semibold text-emerald-700">أرقامنا</p>
          <div className="grid gap-4 text-sm text-emerald-800">
            <div className="rounded-3xl bg-white p-4">
              <p className="text-lg font-bold">+12K</p>
              <p>طلب شهري</p>
            </div>
            <div className="rounded-3xl bg-white p-4">
              <p className="text-lg font-bold">98%</p>
              <p>رضا العملاء</p>
            </div>
            <div className="rounded-3xl bg-white p-4">
              <p className="text-lg font-bold">+4K</p>
              <p>منتج متوفر</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
