import type { FormEvent } from "react";
import { Link } from "react-router-dom";
import SectionHeading from "../components/SectionHeading";

export default function Checkout() {
  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
  };

  return (
    <div className="space-y-10">
      <SectionHeading title="إتمام عملية الدفع" subtitle="الدفع" />
      <div className="grid gap-8 lg:grid-cols-[1.4fr_0.8fr]">
        <form
          onSubmit={handleSubmit}
          className="space-y-6 rounded-[32px] border border-slate-100 bg-white p-8 shadow-sm"
        >
          <div>
            <p className="text-sm font-semibold text-slate-900">بيانات الشحن</p>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <input
                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
                placeholder="الاسم الكامل"
              />
              <input
                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
                placeholder="رقم الجوال"
              />
              <input
                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
                placeholder="المدينة"
              />
              <input
                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:border-emerald-500 focus:outline-none"
                placeholder="الحي والعنوان"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            <button className="flex-1 rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white">
              تأكيد الدفع
            </button>
            <Link
              to="/"
              className="flex-1 rounded-full border border-emerald-200 px-6 py-3 text-center text-sm font-semibold text-emerald-700"
            >
              الرجوع للرئيسية
            </Link>
          </div>
        </form>
        <div className="h-fit rounded-[32px] border border-emerald-100 bg-emerald-50 p-6">
          <p className="text-sm font-semibold text-emerald-700">ملخص سريع</p>
          <ul className="mt-4 space-y-3 text-sm text-emerald-800">
            <li>✅ توصيل مجاني للطلبات فوق 200 درهم</li>
            <li>✅ تغليف فاخر يحافظ على الكتب</li>
            <li>✅ خيارات دفع آمنة متعددة</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
