import { Link } from "react-router-dom";
import { ArrowLeft, Quote, Sparkles } from "lucide-react";
import { useStore } from "../context/StoreContext";
import { highlights, offers, testimonials } from "../data/storeContent";
import ProductCard from "../components/ProductCard";
import SectionHeading from "../components/SectionHeading";

export default function Home() {
  const { products, categories, settings } = useStore();
  const bestSellers = products.filter((product) => product.isBestSeller);
  const newArrivals = products.filter((product) => product.isNew);
  const specialOffers = products.filter((product) => product.isSpecial);

  return (
    <div className="space-y-20">
      <section className="grid gap-10 rounded-[32px] bg-gradient-to-l from-emerald-600 via-teal-500 to-slate-900 p-10 text-white md:grid-cols-[1.2fr_1fr]">
        <div className="space-y-6">
          <p className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-xs font-semibold">
            <Sparkles className="h-4 w-4" />
            متجر كتب فاخر ومتجدد
          </p>
          <h1 className="text-3xl font-bold leading-relaxed md:text-4xl">
            {settings.storeName} تقدم لك تجربة تسوق ثقافية بمستوى العلامات العالمية.
          </h1>
          <p className="text-sm text-emerald-50/90">
            اكتشف إصدارات مختارة، عروض مميزة، وخدمة عملاء تتجاوز توقعاتك.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link
              to="/products"
              className="rounded-full bg-white px-6 py-3 text-sm font-semibold text-slate-900 transition hover:bg-emerald-50"
            >
              استعرض المنتجات
            </Link>
            <Link
              to="/categories"
              className="rounded-full border border-white/60 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
            >
              استكشف التصنيفات
            </Link>
          </div>
        </div>
        <div className="relative overflow-hidden rounded-3xl bg-white/10 p-6">
          <img
            src="https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&w=800&q=80"
            alt="مكتبة حديثة"
            className="h-72 w-full rounded-2xl object-cover shadow-2xl"
          />
          <div className="absolute -bottom-8 -left-8 rounded-3xl bg-white p-5 text-slate-900 shadow-xl">
            <p className="text-xs font-semibold text-emerald-600">مبيعات الشهر</p>
            <p className="text-2xl font-bold">+38%</p>
            <p className="text-xs text-slate-500">نمو في الطلب على الكتب</p>
          </div>
        </div>
      </section>

      <section>
        <SectionHeading
          title="أقسام مختارة بعناية"
          subtitle="التصنيفات"
          action={
            <Link
              to="/categories"
              className="flex items-center gap-2 text-sm font-semibold text-emerald-600"
            >
              عرض الكل <ArrowLeft className="h-4 w-4" />
            </Link>
          }
        />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {categories.map((category) => (
            <div
              key={category.id}
              className="group overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
            >
              <img
                src={category.image}
                alt={category.name}
                className="h-40 w-full object-cover transition duration-500 group-hover:scale-105"
              />
              <div className="space-y-2 p-5">
                <h3 className="text-lg font-semibold text-slate-900">
                  {category.name}
                </h3>
                <p className="text-sm text-slate-500">
                  {category.description}
                </p>
                <div className="flex flex-wrap gap-2 text-xs text-emerald-600">
                  {category.subcategories.slice(0, 3).map((subcategory) => (
                    <span
                      key={subcategory}
                      className="rounded-full border border-emerald-100 bg-emerald-50 px-2 py-1"
                    >
                      {subcategory}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeading title="الأكثر مبيعًا" subtitle="الأكثر طلبًا" />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading title="الإصدارات الجديدة" subtitle="جديدنا" />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {newArrivals.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="grid gap-6 rounded-[32px] bg-slate-900 p-10 text-white md:grid-cols-2">
        <div>
          <SectionHeading title="عروض خاصة" subtitle="لا تفوتها" />
          <p className="text-sm text-slate-200">
            عروض موسمية على مختارات من أفضل الكتب والقرطاسية الفاخرة.
          </p>
        </div>
        <div className="space-y-4">
          {offers.map((offer) => (
            <div
              key={offer.title}
              className="rounded-3xl border border-white/10 bg-white/5 p-5"
            >
              <p className="text-lg font-semibold">{offer.title}</p>
              <p className="text-sm text-slate-200">{offer.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeading title="منتجات مختارة بعروض خاصة" subtitle="عروض خاصة" />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {specialOffers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading title="لماذا مكتبة ربيع؟" subtitle="مميزاتنا" />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {highlights.map((highlight) => (
            <div
              key={highlight.title}
              className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm"
            >
              <h3 className="text-lg font-semibold text-slate-900">
                {highlight.title}
              </h3>
              <p className="mt-2 text-sm text-slate-500">
                {highlight.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeading title="آراء عملائنا" subtitle="تجربة العملاء" />
        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((item) => (
            <div
              key={item.name}
              className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm"
            >
              <Quote className="h-6 w-6 text-emerald-500" />
              <p className="mt-4 text-sm text-slate-600">{item.quote}</p>
              <div className="mt-6">
                <p className="text-sm font-semibold text-slate-900">
                  {item.name}
                </p>
                <p className="text-xs text-slate-500">{item.title}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
