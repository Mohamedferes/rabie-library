import { useEffect } from "react";
import type { CSSProperties } from "react";
import { useStore } from "../context/StoreContext";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { settings } = useStore();

  useEffect(() => {
    document.title = `${settings.storeName} | متجر إلكتروني`;
  }, [settings.storeName]);

  return (
    <div
      className="store-background relative min-h-screen text-slate-900"
      style={{ "--store-background": settings.background } as CSSProperties}
    >
      <Navbar />
      <main className="mx-auto w-full max-w-6xl px-4 pb-16 pt-10">
        {children}
      </main>
      <Footer />
    </div>
  );
}
