import { NavLink } from "react-router-dom";
import Logo from "./Logo";

const links = [
  { to: "/dashboard", label: "نظرة عامة" },
  { to: "/dashboard/products", label: "إدارة المنتجات" },
  { to: "/dashboard/categories", label: "التصنيفات" },
  { to: "/dashboard/orders", label: "الطلبات" },
  { to: "/dashboard/customers", label: "العملاء" },
  { to: "/dashboard/offers", label: "العروض" },
  { to: "/dashboard/coupons", label: "الكوبونات" },
  { to: "/dashboard/settings", label: "إعدادات المتجر" },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto flex w-full max-w-6xl gap-8 px-4 py-10">
        <aside className="hidden w-64 flex-col gap-6 rounded-[32px] border border-slate-100 bg-white p-6 shadow-sm lg:flex">
          <Logo />
          <nav className="space-y-2 text-sm font-semibold">
            {links.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === "/dashboard"}
                className={({ isActive }) =>
                  `block rounded-2xl px-4 py-2 transition ${
                    isActive
                      ? "bg-emerald-600 text-white"
                      : "text-slate-600 hover:bg-emerald-50"
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </nav>
        </aside>
        <div className="flex-1">{children}</div>
      </div>
    </div>
  );
}
