import { useStore } from "../context/StoreContext";

export default function Logo({ className = "" }: { className?: string }) {
  const { settings } = useStore();

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-200">
        <span className="text-xl font-bold text-white">ر</span>
      </div>
      <div>
        <p className="heading-font text-lg text-slate-900">
          {settings.storeName}
        </p>
        <p className="text-xs text-slate-500">علامتك الثقافية الفاخرة</p>
      </div>
    </div>
  );
}
