export default function SectionHeading({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-500">
          {subtitle}
        </p>
        <h2 className="mt-2 text-2xl font-bold text-slate-900 md:text-3xl">
          {title}
        </h2>
      </div>
      {action}
    </div>
  );
}
