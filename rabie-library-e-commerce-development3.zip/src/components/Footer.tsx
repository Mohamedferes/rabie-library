import { Link } from "react-router-dom";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-slate-200 bg-white">
      <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-14 md:grid-cols-[1.2fr_1fr_1fr]">
        <div className="space-y-4">
          <Logo />
          <p className="text-sm text-slate-600">
            مكتبة ربيع هي وجهتك الراقية للكتب والقرطاسية المميزة، نختار لك
            بعناية إصدارات تجمع بين المعرفة والجمال.
          </p>
        </div>
        <div>
          <p className="mb-4 text-sm font-semibold text-slate-900">روابط سريعة</p>
          <ul className="space-y-2 text-sm text-slate-600">
            <li>
              <Link className="hover:text-emerald-600" to="/products">
                جميع المنتجات
              </Link>
            </li>
            <li>
              <Link className="hover:text-emerald-600" to="/categories">
                التصنيفات
              </Link>
            </li>
            <li>
              <Link className="hover:text-emerald-600" to="/faq">
                الأسئلة الشائعة
              </Link>
            </li>
            <li>
              <Link className="hover:text-emerald-600" to="/contact">
                تواصل معنا
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="mb-4 text-sm font-semibold text-slate-900">
            اشترك في النشرة
          </p>
          <p className="text-sm text-slate-600">
            احصل على عروض حصرية وإصدارات جديدة أولاً بأول.
          </p>
          <div className="mt-4 flex gap-2">
            <input
              className="w-full rounded-full border border-slate-200 px-4 py-2 text-sm focus:border-emerald-500 focus:outline-none"
              placeholder="البريد الإلكتروني"
            />
            <button className="rounded-full bg-emerald-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-emerald-500">
              اشترك
            </button>
          </div>
        </div>
      </div>
      <div className="border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        جميع الحقوق محفوظة © مكتبة ربيع 2026
      </div>
    </footer>
  );
}
