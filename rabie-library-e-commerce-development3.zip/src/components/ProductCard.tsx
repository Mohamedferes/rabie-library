import { Heart, ShoppingBag, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { Product } from "../context/StoreContext";
import { useStore } from "../context/StoreContext";

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart, toggleWishlist, wishlist } = useStore();
  const isWished = wishlist.includes(product.id);

  return (
    <div className="group flex h-full flex-col overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
      <div className="relative overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="h-56 w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <button
          onClick={() => toggleWishlist(product.id)}
          className={`absolute left-4 top-4 rounded-full border border-white/40 bg-white/80 p-2 transition ${
            isWished ? "text-rose-500" : "text-slate-500"
          }`}
        >
          <Heart className="h-4 w-4" />
        </button>
        {(product.isBestSeller || product.isNew || product.isSpecial) && (
          <div className="absolute right-4 top-4 rounded-full bg-emerald-600 px-3 py-1 text-xs font-semibold text-white shadow">
            {product.isBestSeller
              ? "الأكثر مبيعًا"
              : product.isNew
              ? "جديد"
              : "عرض خاص"}
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-4 p-5">
        <div>
          <Link
            to={`/products/${product.id}`}
            className="text-lg font-semibold text-slate-900 hover:text-emerald-600"
          >
            {product.name}
          </Link>
          <p className="text-sm text-slate-500">{product.author}</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-amber-500">
          <Star className="h-4 w-4 fill-current" />
          <span>{product.rating}</span>
        </div>
        <div className="mt-auto flex items-center justify-between">
          <p className="text-lg font-bold text-slate-900">{product.price} درهم</p>
          <button
            onClick={() => addToCart(product.id)}
            className="flex items-center gap-2 rounded-full bg-slate-900 px-4 py-2 text-xs font-semibold text-white transition hover:bg-slate-800"
          >
            <ShoppingBag className="h-4 w-4" />
            أضف للسلة
          </button>
        </div>
      </div>
    </div>
  );
}
