import { Link, NavLink } from "react-router-dom";
import { Heart, ShoppingBag, UserCircle } from "lucide-react";
import Logo from "./Logo";

const navLinks = [
  { to: "/", label: "الرئيسية" },
  { to: "/products", label: "جميع المنتجات" },
  { to: "/categories", label: "التصنيفات" },
  { to: "/offers", label: "العروض" },
  { to: "/about", label: "من نحن" },
  { to: "/contact", label: "تواصل معنا" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/20 bg-white/80 backdrop-blur-xl">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-6 px-4 py-4">
        <Logo />
        <nav className="hidden items-center gap-6 text-sm font-semibold text-slate-600 lg:flex">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `transition hover:text-emerald-600 ${
                  isActive ? "text-emerald-600" : "text-slate-600"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <Link
            to="/wishlist"
            className="rounded-full border border-emerald-100 bg-emerald-50 p-2 text-emerald-700 transition hover:bg-emerald-100"
          >
            <Heart className="h-5 w-5" />
          </Link>
          <Link
            to="/cart"
            className="rounded-full border border-emerald-100 bg-emerald-50 p-2 text-emerald-700 transition hover:bg-emerald-100"
          >
            <ShoppingBag className="h-5 w-5" />
          </Link>
          <Link
            to="/login"
            className="rounded-full border border-slate-200 p-2 text-slate-600 transition hover:border-emerald-200 hover:text-emerald-600"
          >
            <UserCircle className="h-5 w-5" />
          </Link>

        </div>
      </div>
    </header>
  );
}
